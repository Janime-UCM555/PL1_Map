using System.Collections;
using System.Collections.Generic;
using TreeEditor;
using UnityEngine;

public class LinkMovement : MonoBehaviour
{
    static private LinkMovement _link;
    static public LinkMovement Link
    {
        get { return _link; }
    }

    public float _xvalue;
    public float _yvalue;
    private Vector2 _directionVector;
    private Vector3 _movementVector;
    public float SpeedValue = 2f;
    public void RegisterX(float x)
    {
        _xvalue = x;
    }

    public void RegisterY(float y)
    {
        _yvalue = y;
    }
    void Awake()
    {
        _link = GetComponent<LinkMovement>();
    }
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (_xvalue == 1 || _xvalue == -1)
        {
            _yvalue = 0;
        }
        else if (_yvalue == 1 || _yvalue == -1)
        {
            _xvalue = 0;
        }
        _directionVector = new Vector2(_xvalue, _yvalue);
        _movementVector = SpeedValue * _directionVector * Time.deltaTime;

        transform.position = transform.position + _movementVector;
    }
}
