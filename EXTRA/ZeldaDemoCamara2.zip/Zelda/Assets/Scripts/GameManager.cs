using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    static private GameManager _game;
    static public GameManager Game
    {
        get { return _game; }
    }

    [SerializeField]
    private CameraMovement _camera;

    public void MoveCamera()
    {
        _camera.Move();
    }

    void Awake()
    {
        _game = GetComponent<GameManager>();
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
