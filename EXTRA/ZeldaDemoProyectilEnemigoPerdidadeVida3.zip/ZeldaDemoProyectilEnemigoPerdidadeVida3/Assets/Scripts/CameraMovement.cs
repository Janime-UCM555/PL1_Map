using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    private Transform _myTransform;
    private float x, y; 
    public void Move()
    {
        x = LinkMovement.Link._xvalue;
        y = LinkMovement.Link._yvalue;
    }
    // Start is called before the first frame update
    void Start()
    {
        _myTransform = transform;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        _myTransform.position = _myTransform.position + Vector3.right * 32 * x + Vector3.up * 10 * y;
        x = y = 0;
    }
}
