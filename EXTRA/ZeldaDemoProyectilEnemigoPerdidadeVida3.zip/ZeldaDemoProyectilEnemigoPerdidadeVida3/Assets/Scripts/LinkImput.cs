using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LinkInput : MonoBehaviour
{
    private LinkMovement _linkMovement;
    // Start is called before the first frame update
    void Start()
    {
        _linkMovement = GetComponent<LinkMovement>();
    }

    // Update is called once per frame
    void Update()
    {
        _linkMovement.RegisterX(Input.GetAxisRaw("Horizontal"));
        _linkMovement.RegisterY(Input.GetAxisRaw("Vertical"));
    }
}
