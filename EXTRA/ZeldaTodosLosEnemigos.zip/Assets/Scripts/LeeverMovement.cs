using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class LeeverMovement : MonoBehaviour
{
    public Transform m_target;
    public Transform m_transform;
    public float _movementspeed = 5;
    public Vector3 _movementdirection;
   
    private SpriteRenderer _spriteRenderer;
    [SerializeField]
    private LayerMask colision;
    [SerializeField]
    private LayerMask bounds;
    private ShootingComponent _shooting;
    private Vector3 directionToPlayer;
    [SerializeField] private Transform _targetTransform;
    private Animator _myAnimator;
    int x;
    private bool _stopToShoot = false;
    public int cuenta = 1;
 
    public void StopToShoot()
    {
        _stopToShoot = true;
        _movementspeed = 0;

    }

    public void NotStopToShoot()
    {
        _stopToShoot = false;
        _movementspeed = 5;
    }
 

    private bool isWalkable(Vector3 targetPosition)
    {
        if (Physics2D.OverlapCircle(targetPosition, 0.7f, colision | bounds) != null) return false;
        return true;
    }
    


    
        public void Comportamientoenemigo()
        {
            if (m_target.position.x > m_transform.position.x)
            {
                x = 1;
            }
            else if (m_target.position.x < m_transform.position.x)
            {
                x = -1;
            }
        }
    
    // Start is called before the first frame update
    void Start()
    {
        m_transform = GetComponent<Transform>();
        _spriteRenderer = GetComponent<SpriteRenderer>();
        _shooting = GetComponent<ShootingComponent>();
        _myAnimator = GetComponent<Animator>();
        Comportamientoenemigo();
    }

    // Update is called once per frame
    void Update()
    {
       
        m_transform.Translate(_movementdirection = new Vector3(x, 0, 0) * _movementspeed * Time.deltaTime);

      
                                

    }
}

