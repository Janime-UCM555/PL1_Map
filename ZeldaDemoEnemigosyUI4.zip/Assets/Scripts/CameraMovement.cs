using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    private Transform _myTransform;
    private float x, y;
    [SerializeField] private float desiredTime = 3f;
    private float elapsedTime = 0f;
    Vector3 targetPosition;
    Vector3 position;


    public void Move()
    {
        x = LinkMovement.Link._xvalue;//myrigidbody.velocity.x.normalize
        y = LinkMovement.Link.yvalue;
        if (targetPosition == position ) targetPosition = position + Vector3.right * 32 * x + Vector3.up * 10 * y;
        elapsedTime = 0f;
    }
    // Start is called before the first frame update
    void Start()
    {
        _myTransform = transform;
        targetPosition = _myTransform.position;
        position = _myTransform.position;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        _myTransform.position = Vector3.Lerp(position, targetPosition, elapsedTime/desiredTime);
        x = y = 0;
        if (elapsedTime > desiredTime)
        {
            elapsedTime = 0f;
            position = _myTransform.position;
        }
    }
    private void Update()
    {
        elapsedTime += Time.deltaTime;
    }
}
